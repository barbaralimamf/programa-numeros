﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
            string numero, opcao;

            do
            {
                Console.WriteLine("SELECIONE UMA OPÇÃO");
                Console.WriteLine("s- NUMERO");
                Console.WriteLine("n- SAIR");

                opcao = Console.ReadLine();

                if (opcao == "s")
                {
                    Console.Clear();
                    Console.WriteLine("Insira o numero");
                    numero = Console.ReadLine();
                    Console.ReadKey();

                }

                else if (opcao == "n")
                {
                    Console.Clear();
                    Console.ReadKey();

                }

            }

            while (opcao != "n");
            Console.WriteLine("Encerrando o programa...");
            Console.ReadKey();
        }
    }
}
